create database base1;
show databases;
exit