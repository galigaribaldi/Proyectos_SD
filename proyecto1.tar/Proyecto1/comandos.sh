sudo apt update 
sudo apt upgrade 
sudo apt install mariadb-server
sudo mysql_secure_installation 
mysql --version
sudo mysql
sudo systemctl status
sudo systemctl status mariadb
sudo mysqladmin version
mysql -u gali -p